import { Component } from '@angular/core';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  public name: string;
  public id: string;

  constructor() {
    this.name = 'Seth Pletcher';
    this.id = '0926867';
  }

}
